#include <iostream>
using namespace std;
int main()
{
    double r,pi=3.14159;
    cin>>r;
    cout<<2*r<<" "<<2*pi*r<<" "<<pi*r*r;
}
