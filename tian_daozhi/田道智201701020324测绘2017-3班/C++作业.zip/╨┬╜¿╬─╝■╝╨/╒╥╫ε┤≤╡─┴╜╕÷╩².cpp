#include <iostream>
using namespace std;
int main()
{
    int s[15],t;
    for(int i=0;i<10;i++)
    {
        cin>>s[i];
        if(s[0]<s[i])
        {
            t=s[0];
            s[0]=s[i];
            s[i]=t;
        }
    }
    for(int i=2;i<10;i++)
    {
        if(s[i]>s[1])
        {
            t=s[1];
            s[1]=s[i];
            s[i]=t;
        }
    }
    cout<<s[0]<<" "<<s[1]<<endl;

}
