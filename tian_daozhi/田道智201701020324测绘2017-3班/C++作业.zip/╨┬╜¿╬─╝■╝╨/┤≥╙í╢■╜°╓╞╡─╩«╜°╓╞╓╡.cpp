#include <iostream>
using namespace std;
int main()
{
    char s[100];
    int i=0,sum=0;
    cin>>s;
    while(s[i]!='\0')
    {
        sum=sum*2+(s[i]-'0');
        i++;
    }
    cout<<sum;
}
